// Header comment
// Developer: John Doe
// Date: January 1, 2021
// Purpose: Print "Hello, World!"

#include <iostream>

int main() {
    // Print "Hello, World!" to the console
    std::cout << "Hello, World!" << std::endl;
    return 0;
}