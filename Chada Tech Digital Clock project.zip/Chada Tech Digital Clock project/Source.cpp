#include <iostream>
#include <ctime>
#include <iomanip>
#include <string>
using namespace std;

class Clock {
    int hour, minute, second;
public:
    Clock() {

        //https://cpp.hotexamples.com/examples/-/-/localtime_s/cpp-localtime_s-function-examples.html

        time_t rawtime;
        struct tm timeinfo;
        time(&rawtime);
        localtime_s(&timeinfo, &rawtime);

        hour = timeinfo.tm_hour;
        minute = timeinfo.tm_min;
        second = timeinfo.tm_sec;
    }
    Clock(int h, int m, int s) {
        hour = h;
        minute = m;
        second = s;
    }
    int getHour() {
        return hour;
    }
    int getMinute() {
        return minute;
    }
    int getSecond() {
        return second;
    }
    void setHour(int h) {
        hour = h;
    }
    void setMinute(int m) {
        minute = m;
    }
    void setSecond(int s) {
        second = s;
    }
    void incrementSecond() {
        second++;
        if (second >= 60) {
            second -= 60;
            incrementMinute();
        }
    }
    void incrementMinute() {
        minute++;
        if (minute >= 60) {
            minute -= 60;
            incrementHour();
        }
    }
    void incrementHour() {
        hour++;
        if (hour >= 24) {
            hour -= 24;
        }
    }
    void display12Hour() {
        int hour12 = (hour % 12 == 0) ? 12 : hour % 12;

        for (int i = 0; i < 25; i++) {
            cout << "*";
        }
        cout << endl;

        cout << "*";
        for (int i = 0; i < 7; i++) {
            cout << " ";
        }

        cout << "12-Hour Clock";

        for (int i = 0; i < 3; i++) {
            cout << " ";
        }
        cout << "*" << endl;

        cout << "*";
        for (int i = 0; i < 7; i++) {
            cout << " ";
        }

        cout << setw(2) << setfill('0') << hour12 << ":" << setw(2) << setfill('0') << minute << ":" << setw(2) << setfill('0') << second;
        cout << (hour < 12 ? " A M" : " P M");

        for (int i = 0; i < 4; i++) {
            cout << " ";
        }
        cout << "*" << endl;

        for (int i = 0; i < 25; i++) {
            cout << "*";
        }
        cout << endl;
    }



    void display24Hour() {
        string h = to_string(hour);
        string m = to_string(minute);
        string s = to_string(second);

        if (hour < 10) {
            h = "0" + h;
        }

        if (minute < 10) {
            m = "0" + m;
        }

        if (second < 10) {
            s = "0" + s;
        }

        string time = "       " + h + ":" + m + ":" + s;

        cout << setfill(' ');

        cout << "*************************" << endl;
        cout << left << "*" << setw(23) << "       24-Hour Clock" << "*" << endl;
        cout << left << "*" << setw(23) << time << "*" << endl;
        cout << "*************************" << endl;
    }

    void displayClocks() {
        int hour12 = (hour % 12 == 0) ? 12 : hour % 12;
        string h12 = to_string(hour12);
        string h = to_string(hour);
        string m = to_string(minute);
        string s = to_string(second);

        if (hour12 < 10) {
            h12 = "0" + h12;
        }

        if (hour < 10) {
            h = "0" + h;
        }

        if (minute < 10) {
            m = "0" + m;
        }

        if (second < 10) {
            s = "0" + s;
        }

        string time = "       " + h + ":" + m + ":" + s;
        string time12 = "       " + h12 + ":" + m + ":" + s + (hour < 12 ? " A M" : " P M");

        cout << setfill(' ');

        cout << "*************************";
        cout << "               ";
        cout << "*************************" << endl;

        cout << left << "*" << setw(23) << "       12-Hour Clock" << "*";
        cout << "               ";
        cout << left << "*" << setw(23) << "       24-Hour Clock" << "*" << endl;
        cout << left << "*" << setw(23) << time12 << "*";
        cout << "               ";
        cout << left << "*" << setw(23) << time << "*" << endl;

        cout << "*************************";
        cout << "               ";
        cout << "*************************" << endl;
    }
};

void displayMenu() {
    cout << setfill(' ');
    cout << "*************************" << endl;
    cout << left << "*" << setw(23) << " 1 - Add One Hour" << "*" << endl;
    cout << left << "*" << setw(23) << " 2 - Add One Minute" << "*" << endl;
    cout << left << "*" << setw(23) << " 3 - Add One Second" << "*" << endl;
    cout << left << "*" << setw(23) << " 4 - Exit Program" << "*" << endl;
    cout << "*************************" << endl;
}

int main() {
    Clock clock12, clock24;

    //clock12.display12Hour();
    //cout << "24-Hour Clock: ";
    //clock24.display24Hour();

    clock12.displayClocks();
    cout << endl;
    displayMenu();

    int choice;
    cin >> choice;

    while (choice >= 1 && choice < 4) {
        switch (choice) {
        case 1:
            clock12.incrementHour();
            break;
        case 2:
            clock12.incrementMinute();
            break;
        case 3:
            clock12.incrementSecond();
            break;
        }

        clock12.displayClocks();

        cin >> choice;
    }

    return 0;
}