#include <iostream>
using namespace std;

int main()
{
    // Declare variables for the two operands and the operation
    int op1, op2;
    char operation;
    char answer = 'Y';

    // Loop until the user chooses not to continue
    while (answer == 'Y')
    {
        // Prompt the user to enter an expression
        cout << "Enter expression" << endl;
        cin >> op1 >> operation >> op2;

        // Evaluate the expression and output the result
        if (operation == '+')
        {
            cout << op1 << " + " << op2 << " = " << op1 + op2 << endl;
        }
        else if (operation == '-')
        {
            cout << op1 << " - " << op2 << " = " << op1 - op2 << endl;
        }
        else if (operation == '*')
        {
            cout << op1 << " * " << op2 << " = " << op1 * op2 << endl;
        }
        else if (operation == '/')
        {
            cout << op1 << " / " << op2 << " = " << op1 / op2 << endl;
        }
        else
        {
            cout << "Invalid operator" << endl;
        }

        // Prompt the user to continue or not
        cout << "Do you wish to evaluate another expression? (Y/N) ";
        cin >> answer;
    }
    return 0;
}
